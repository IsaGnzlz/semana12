let usuarios = [];

function renderUsuarios(lista = usuarios) {
  const cont = document.getElementById('users-list');
  cont.innerHTML = '';

  lista.forEach((u) => {
    const card = document.createElement('div');
    card.style.background = '#fff';
    card.style.borderRadius = '10px';
    card.style.boxShadow = '0 2px 8px #0001';
    card.style.padding = '20px';
    card.style.display = 'flex';
    card.style.flexDirection = 'column';
    card.style.gap = '8px';
    card.style.position = 'relative';

    card.innerHTML = `
      <p><strong>Usuario:</strong> ${u.user}</p>
      <p><strong>Email:</strong> ${u.email}</p>
      <p><strong>Grado:</strong> ${u.grado || ''}</p>
      <p><strong>Horas:</strong> ${u.horas || 0}</p>
      <div style="margin-top:10px;">
        <button onclick="modificarHoras('${u.email}', -1)" style="font-size:14px;">-</button>
        <span id="horas-${u.email}">${u.horas || 0}</span>
        <button onclick="modificarHoras('${u.email}', 1)" style="font-size:14px;">+</button>
        <button onclick="eliminarUsuario('${u.email}')" style="font-size:12px; padding:2px 6px; margin-left:10px; background:#e74c3c; color:white; border:none; border-radius:4px; cursor:pointer;">🗑️ Eliminar</button>
      </div>
    `;
    cont.appendChild(card);
  });
}

// Obtener usuarios desde la API
fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });

// Búsqueda en tiempo real
document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        (u.user && u.user.toLowerCase().includes(texto)) ||
        (u.email && u.email.toLowerCase().includes(texto)) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }
});

// Funciones modificarHoras y eliminarUsuario deben estar definidas igual que antes

function mostrarInfoUsuario(usuario) {
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.background = 'rgba(0,0,0,0.5)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:10px; min-width:300px; position:relative;">
      <button style="position:absolute; top:10px; right:10px; font-size:18px; background:none; border:none; cursor:pointer;" onclick="this.parentNode.parentNode.remove()">✖</button>
      <h2>Información del usuario</h2>
      <p><strong>Usuario:</strong> ${usuario.user}</p>
      <p><strong>Email:</strong> ${usuario.email}</p>
      <p><strong>Contraseña:</strong> ${usuario.password}</p>
      <p><strong>Grado:</strong> ${usuario.grado || ''}</p>
      <p><strong>Rol:</strong> ${usuario.role || ''}</p>
    </div>
  `;
  document.body.appendChild(modal);
}

// Obtener usuarios desde la API
fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });

document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        u.user.toLowerCase().includes(texto) ||
        u.email.toLowerCase().includes(texto) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }
});

// Nueva función para eliminar usuario
async function eliminarUsuario(email) {
  if (confirm("¿Seguro que deseas eliminar este usuario?")) {
    const res = await fetch('/api/deleteUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (data.success) {
      usuarios = usuarios.filter(u => u.email !== email);
      renderUsuarios();
    } else {
      alert(data.error || "No se pudo eliminar el usuario");
    }
  }
}

async function modificarHoras(email, cambio) {
  const res = await fetch('/api/modificarHoras', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, cambio })
  });
  const data = await res.json();
  if (data.success) {
    document.getElementById(`horas-${email}`).textContent = data.horas;
    // Actualiza el array local si lo usas
    const usuario = usuarios.find(u => u.email === email);
    if (usuario) usuario.horas = data.horas;
  } else {
    alert(data.message || 'No se pudo modificar las horas');
  }
}