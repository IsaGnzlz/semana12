import express from "express";
//dirname
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
// ...existing code...
import fs from "fs";

//Server 
const app = express();
app.set("port",4000)
app.listen(app.get("port"));
console.log("Servidor corriendo en el puerto", app.get("port"));

//Configuracion
app.use(express.static(__dirname + "/public"));
app.use(express.json());


//Rutas
app.get("/",(req, res) => res.sendFile(__dirname + "/pages/login.html"))
app.get("/register", (req, res) => res.sendFile(__dirname + "/pages/register.html"));
app.get("/adminpage", (req, res) => res.sendFile(__dirname + "/pages/adminpage.html"));
app.get("/userpage", (req, res) => res.sendFile(__dirname + "/pages/userpage.html"));
app.get("/contactanos", (req, res) => res.sendFile(__dirname + "/pages/contactanos.html"));
app.get("/sobrenosotros", (req, res) => res.sendFile(__dirname + "/pages/sobrenosotros.html"));
app.get("/mensajes", (req, res) => res.sendFile(__dirname + "/pages/mensajes.html"));


app.post('/login', (req, res) => {
    const { email, password } = req.body;
    // Supón que tienes un array de usuarios
    const users = JSON.parse(fs.readFileSync('app/users.json'));
    const user = users.find(u => (u.email === email || u.user === email) && u.password === password);

    if (user) {
        // Puedes usar sesiones aquí si lo deseas
        res.json({ success: true, role: user.role });
    } else {
        res.json({ success: false, message: 'Credenciales incorrectas' });
    }
});

app.post("/api/register", (req, res) => {
    const { user, email, password, role, grado } = req.body;
    if (!user || !email || !password || !role || !grado) {
        return res.json({ success: false, message: "Todos los campos son obligatorios" });
    }
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    if (users.find(u => u.email === email)) {
        return res.json({ success: false, message: "El correo ya está registrado" });
    }
    users.push({
        user,
        email,
        password,
        role,
        grado
    });
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    res.json({ success: true });
});


app.get("/api/users", (req, res) => {
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    res.json(users);
});


app.post("/api/deleteUser", (req, res) => {
    const { email } = req.body;
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    const newUsers = users.filter(u => u.email !== email);
    if (newUsers.length === users.length) {
        return res.status(404).json({ error: "Usuario no encontrado" });
    }
    fs.writeFileSync(usersFile, JSON.stringify(newUsers, null, 2));
    res.json({ success: true });
});

const mensajesFile = __dirname + '/mensajes.json';

app.post('/send-message', (req, res) => {
    const { name, email, message } = req.body;
    let mensajes = [];
    if (fs.existsSync(mensajesFile)) {
        mensajes = JSON.parse(fs.readFileSync(mensajesFile));
    }
    mensajes.push({ name, email, message, date: new Date() });
    fs.writeFileSync(mensajesFile, JSON.stringify(mensajes, null, 2));
    res.redirect('/mensajes');
});

app.get('/mensajes', (req, res) => {
    let mensajes = [];
    if (fs.existsSync(mensajesFile)) {
        mensajes = JSON.parse(fs.readFileSync(mensajesFile));
    }
    // Si usas plantillas, pásalos a la vista. Si usas HTML estático, puedes servir un endpoint JSON:
    res.sendFile(__dirname + '/pages/mensajes.html');
});

// Endpoint para obtener mensajes en JS
app.get('/api/mensajes', (req, res) => {
    let mensajes = [];
    if (fs.existsSync(mensajesFile)) {
        mensajes = JSON.parse(fs.readFileSync(mensajesFile));
    }
    res.json(mensajes);
});

app.post('/send-message', (req, res) => {
    const { name, email, message } = req.body;
    // ...guardar mensaje como antes...
    res.status(200).json({ success: true });
});

app.post('/api/deleteMensaje', (req, res) => {
    const { date } = req.body;
    let mensajes = [];
    if (fs.existsSync(mensajesFile)) {
        mensajes = JSON.parse(fs.readFileSync(mensajesFile));
    }
    const newMensajes = mensajes.filter(m => m.date !== date);
    if (newMensajes.length === mensajes.length) {
        return res.status(404).json({ error: "Mensaje no encontrado" });
    }
    fs.writeFileSync(mensajesFile, JSON.stringify(newMensajes, null, 2));
    res.json({ success: true });
});