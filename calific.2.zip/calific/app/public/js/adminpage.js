function renderUsuarios(lista = usuarios) {
  const cont = document.getElementById('users-list');
  cont.innerHTML = '';

  lista.forEach((u) => {
    const card = document.createElement('div');
    card.style.background = '#fff';
    card.style.borderRadius = '10px';
    card.style.boxShadow = '0 2px 8px #0001';
    card.style.padding = '20px';
    card.style.cursor = 'pointer';
    card.style.border = '1px solid #eee';

    card.innerHTML = `
      <p><strong>Usuario:</strong> ${u.user}</p>
      <p><strong>Email:</strong> ${u.email}</p>
      <p><strong>Contraseña:</strong> ${u.password}</p>
      <p><strong>Grado:</strong> ${u.grado || ''}</p>
      <p><strong>Rol:</strong> ${u.role || ''}</p>
    `;
    card.onclick = () => mostrarInfoUsuario(u);
    cont.appendChild(card);
  });
}

function mostrarInfoUsuario(usuario) {
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.background = 'rgba(0,0,0,0.5)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:10px; min-width:300px; position:relative;">
      <button style="position:absolute; top:10px; right:10px; font-size:18px; background:none; border:none; cursor:pointer;" onclick="this.parentNode.parentNode.remove()">✖</button>
      <h2>Información del usuario</h2>
      <p><strong>Usuario:</strong> ${usuario.user}</p>
      <p><strong>Email:</strong> ${usuario.email}</p>
      <p><strong>Contraseña:</strong> ${usuario.password}</p>
      <p><strong>Grado:</strong> ${usuario.grado || ''}</p>
      <p><strong>Rol:</strong> ${usuario.role || ''}</p>
    </div>
  `;
  document.body.appendChild(modal);
}

// Obtener usuarios desde la API
fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });

document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        u.user.toLowerCase().includes(texto) ||
        u.email.toLowerCase().includes(texto) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }
});

// Nueva función para eliminar usuario
async function eliminarUsuario(email) {
  if (confirm("¿Seguro que deseas eliminar este usuario?")) {
    const res = await fetch('/api/deleteUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (data.success) {
      usuarios = usuarios.filter(u => u.email !== email);
      renderUsuarios();
    } else {
      alert(data.error || "No se pudo eliminar el usuario");
    }
  }
}