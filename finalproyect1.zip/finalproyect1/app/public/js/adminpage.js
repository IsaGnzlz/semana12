let usuarios = [];

function renderUsuarios(lista = usuarios) {
  const cont = document.getElementById('users-list');
  cont.innerHTML = '';

  lista.forEach((u) => {
    const card = document.createElement('div');
    card.className = 'admin-user-card';
    let horasHTML = '';
    if (u.role !== 'admin' && u.role !== 'administrador') {
      horasHTML = `<p><strong>Horas:</strong> ${u.horas ?? 'No registradas'}</p>`;
    }

    card.innerHTML = `
      <p><strong>Usuario:</strong> ${u.user}</p>
      <p><strong>Email:</strong> ${u.email}</p>
      <p><strong>Grado:</strong> ${u.grado || ''}</p>
      ${horasHTML}
        <button class="delete-btn" onclick="eliminarUsuario('${u.email}')">🗑️ Eliminar</button>
      </div>
      <span id="checkmark-${u.email}"></span>
    `;
    cont.appendChild(card);

    // SOLO para usuarios que NO son admin
    if (u.role !== 'admin' && u.role !== 'administrador') {
      const btnHoras = document.createElement('button');
      btnHoras.textContent = 'Horas';
      btnHoras.onclick = function() {
          window.location.href = '/horas?email=' + encodeURIComponent(u.email);
      };
      card.appendChild(btnHoras);

      const btnAnadirHoras = document.createElement('button');
      btnAnadirHoras.textContent = 'Añadir horas';
      btnAnadirHoras.onclick = function() {
          window.location.href = '/anadirhoras?email=' + encodeURIComponent(u.email);
      };
      card.appendChild(btnAnadirHoras);
    }
  });
}

fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });

document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        (u.user && u.user.toLowerCase().includes(texto)) ||
        (u.email && u.email.toLowerCase().includes(texto)) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }
});


function mostrarInfoUsuario(usuario) {
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.background = 'rgba(0,0,0,0.5)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:10px; min-width:300px; position:relative;">
      <button style="position:absolute; top:10px; right:10px; font-size:18px; background:none; border:none; cursor:pointer;" onclick="this.parentNode.parentNode.remove()">✖</button>
      <h2>Información del usuario</h2>
      <p><strong>Usuario:</strong> ${usuario.user}</p>
      <p><strong>Email:</strong> ${usuario.email}</p>
      <p><strong>Contraseña:</strong> ${usuario.password}</p>
      <p><strong>Grado:</strong> ${usuario.grado || ''}</p>
      <p><strong>Rol:</strong> ${usuario.role || ''}</p>
    </div>
  `;
  document.body.appendChild(modal);
}

fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });

document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        u.user.toLowerCase().includes(texto) ||
        u.email.toLowerCase().includes(texto) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }
});

async function eliminarUsuario(email) {
  if (confirm("¿Seguro que deseas eliminar este usuario?")) {
    const res = await fetch('/api/deleteUser', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (data.success) {
      usuarios = usuarios.filter(u => u.email !== email);
      renderUsuarios();
    } else {
      alert(data.error || "No se pudo eliminar el usuario");
    }
  }
}

async function modificarHoras(email, cambio) {
  const res = await fetch('/api/modificarHoras', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, cambio })
  });
  const data = await res.json();
  if (data.success) {
    document.getElementById(`horas-${email}`).textContent = data.horas;
    const usuario = usuarios.find(u => u.email === email);
    if (usuario) usuario.horas = data.horas;
    if (cambio > 0) {
      const checkSpan = document.getElementById(`checkmark-${email}`);
      if (checkSpan) {
        checkSpan.innerHTML = '<span class="checkmark">✔️</span>';
        setTimeout(() => { checkSpan.innerHTML = ''; }, 1200);
      }
    }
  } else {
    alert(data.message || 'No se pudo modificar las horas');
  }
}