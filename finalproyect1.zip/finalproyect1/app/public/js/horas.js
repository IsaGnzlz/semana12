function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}
const emailUsuario = getQueryParam('email'); // SOLO AQUÍ

document.addEventListener('DOMContentLoaded', async function() {
    const res = await fetch('/api/horas');
    const horas = await res.json();
    const horasUsuario = horas.filter(h => h.usuario === emailUsuario);
    const tbody = document.querySelector('#tabla-horas tbody');
    if (tbody) {
        tbody.innerHTML = '';
        horasUsuario.forEach(hora => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${hora.directivo}</td>
                <td>${hora.actividad}</td>
                <td>${hora.fecha ? new Date(hora.fecha).toLocaleString() : ''}</td>
            `;
            tbody.appendChild(tr);
        });
    }
});