function renderUsuarios(lista = usuarios) {
  const cont = document.getElementById('users-list');
  cont.innerHTML = '';

  lista.forEach((u) => {
    const card = document.createElement('div');
    card.className = 'user-card';
    card.innerHTML = `
      <p><strong>Usuario:</strong> ${u.user}</p>
      <p><strong>Email:</strong> ${u.email}</p>
      <p><strong>Grado:</strong> ${u.grado || ''}</p>
      <p><strong>Horas:</strong> ${u.horas ?? 'No registradas'}</p>
    `;
    card.onclick = () => mostrarInfoUsuario(u);
    cont.appendChild(card);
  });
}

function mostrarInfoUsuario(usuario) {
  const modal = document.createElement('div');
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.background = 'rgba(0,0,0,0.5)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.innerHTML = `
    <div style="background:#fff; padding:30px; border-radius:10px; min-width:300px; position:relative;">
      <button style="position:absolute; top:10px; right:10px; font-size:18px; background:none; border:none; cursor:pointer;" onclick="this.parentNode.parentNode.remove()">✖</button>
      <h2>Información del usuario</h2>
      <p><strong>Usuario:</strong> ${usuario.user}</p>
      <p><strong>Email:</strong> ${usuario.email}</p>
      <p><strong>Grado:</strong> ${usuario.grado || ''}</p>
      <p><strong>Horas:</strong> ${usuario.horas ?? 'No registradas'}</p>
    </div>
  `;
  document.body.appendChild(modal);
}


document.addEventListener('DOMContentLoaded', function() {
  const inputBusqueda = document.getElementById('busqueda-usuario');
  if (inputBusqueda) {
    inputBusqueda.addEventListener('input', function() {
      const texto = inputBusqueda.value.toLowerCase();
      const filtrados = usuarios.filter(u =>
        u.user.toLowerCase().includes(texto) ||
        u.email.toLowerCase().includes(texto) ||
        (u.grado && u.grado.toLowerCase().includes(texto))
      );
      renderUsuarios(filtrados);
    });
  }

  // Animación de reloj
  function updateClock() {
    const now = new Date();
    const hour = now.getHours() % 12;
    const minute = now.getMinutes();
    const second = now.getSeconds();
    const hourDeg = (hour + minute / 60) * 30;
    const minuteDeg = (minute + second / 60) * 6;
    const secondDeg = second * 6;
    const hourHand = document.getElementById('clock-hour');
    const minuteHand = document.getElementById('clock-minute');
    const secondHand = document.getElementById('clock-second');
    if (hourHand && minuteHand && secondHand) {
      hourHand.style.transform = `translate(-50%, -100%) rotate(${hourDeg}deg)`;
      minuteHand.style.transform = `translate(-50%, -100%) rotate(${minuteDeg}deg)`;
      secondHand.style.transform = `translate(-50%, -100%) rotate(${secondDeg}deg)`;
    }
  }
  setInterval(updateClock, 1000);
  updateClock();
});

// Obtener usuarios desde la API
fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });
