function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}
const emailUsuario = getQueryParam('email');

document.addEventListener('DOMContentLoaded', async function() {
    // Llenar select de directivos
    const selectDirectivo = document.getElementById('directivo');
    if (selectDirectivo) {
        try {
            const res = await fetch('/api/users');
            const users = await res.json();
            const admins = users.filter(u => u.role === 'admin' || u.role === 'administrador');
            admins.forEach(admin => {
                const option = document.createElement('option');
                option.value = admin.email;
                option.textContent = `${admin.user} (${admin.email})`;
                selectDirectivo.appendChild(option);
            });
        } catch (err) {
            console.error('Error al cargar los directivos:', err);
        }
    }

    // Enviar formulario
    const form = document.getElementById('anadir-horas-form');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const data = {
                usuario: emailUsuario, // ¡Aquí se guarda el email del usuario!
                directivo: form.directivo.value,
                actividad: form.actividad.value,
                fecha: new Date().toISOString()
            };
            await fetch('/api/horas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            alert('Horas guardadas');
            form.reset();
        });
    }
});